public class Camisa extends Produto {
    String cor;
    String tamanho;
    String material;
    String modelo;

    public Camisa (String nome,Double preco,String cor,String tamanho,String material,String modelo){
        super(nome,preco);
        this.cor = cor;
        this.tamanho = tamanho;
        this.material = material;
        this.modelo = modelo;
    }
    @Override
    public void exibirInfo(){
        super.exibirInfo();
        System.out.println("Informações da Camisa");
        System.out.println("Cor: "+cor);
        System.out.println("Tamanho : "+tamanho);
        System.out.println("Material :"+material);
        System.out.println("Modelo :"+modelo );
    }
}
