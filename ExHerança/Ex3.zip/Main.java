public class Main{
    public static void main(String[] args){

        Livro livro = new Livro("Saturno",130.00,"Joacir",433,"Abril",true);
        Camisa camisa = new Camisa("Corintia",170.00,"Branco","M","Poliester","Manga Curta");
        camisa.exibirInfo();
        livro.exibirInfo();
    }
}