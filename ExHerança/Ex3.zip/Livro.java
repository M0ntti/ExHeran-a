public class Livro extends Produto {
    String autor;
    int numeroPaginas;
    String editora;
    boolean capaDura;

    public Livro (String nome,Double preco,String autor,int numeroPaginas,String editora,boolean capaDura){
        super(nome,preco);
        this.autor = autor;
        this.numeroPaginas = numeroPaginas;
        this.editora = editora;
        this.capaDura = capaDura;
    }

    @Override
    public void exibirInfo(){
        super.exibirInfo();
        System.out.println("Informações do Livro");
        System.out.println("Autor: "+autor);
        System.out.println("Numero de paginas : "+numeroPaginas);
        System.out.println("Editora :"+editora);
        System.out.println("Capa Dura :"+capaDura );
    }

}
