public class Produto {
    protected String nome;
    protected Double preco;
    
    public Produto(String nome, Double preco){
        this.nome = nome;
        this.preco = preco;
}

    public void exibirInfo(){
        System.out.println("Nome do produto: "+nome+" Preço R$:"+preco);
    }
}
