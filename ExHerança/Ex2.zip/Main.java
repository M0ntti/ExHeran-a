public class Main {
    public static void main(String[] args) {
        double o[] = {2.2,2.1,2.0,1,13,1,3,5,9,5,7};
        double or[] ={3,2,1,0,10,4,3,6,7,5};

        Ordenador ordem = new Ordenador();
        Ordenador desord = new OrdenadorDecrescente();
        ordem.imprimir(o);
        System.out.println(" ");
        desord.imprimir(or);
        System.out.println(" ");
        ordem.ordenar(o);
        desord.ordenar(or);
        ordem.imprimir(o);
        System.out.println(" ");
        desord.imprimir(or);
        System.out.println(" ");

    }
}