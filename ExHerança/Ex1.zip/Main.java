public class Main {
    public static void main(String args[]){
        OperacaoMatematica s = new Soma();
        s.calcular(1,2);
        Multiplicacao m = new Multiplicacao();
        m.calcular(3,2);
        Subtracao sub = new Subtracao();
        sub.calcular(4,2);
        Divicao d = new Divicao();
        d.calcular(6,2);
    }
}