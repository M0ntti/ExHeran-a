public class Soma extends OperacaoMatematica {

    @Override
    public void calcular(double a, double b){
        System.out.print("A soma de "+a+" e "+b);
        System.out.println(" é "+(a+b));
    }
}
