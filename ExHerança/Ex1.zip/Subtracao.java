public class Subtracao extends OperacaoMatematica{

    @Override
    public void calcular(double a, double b) {
        System.out.print("A subtração de "+a+" e "+b);
        System.out.println(" é "+(a-b));
    }
}
