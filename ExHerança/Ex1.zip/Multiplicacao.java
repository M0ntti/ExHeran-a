public class Multiplicacao extends OperacaoMatematica{

    @Override
    public void calcular(double a, double b) {
        System.out.print("A multiplicação de "+a+" e "+b);
        System.out.println(" é "+(a*b));
    }
}
