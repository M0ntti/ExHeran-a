public class Divicao extends OperacaoMatematica{

    @Override
    public void calcular(double a, double b) {
        System.out.print("A divizão de "+a+" e "+b);
        System.out.println(" é "+(a/b));
    }
}
