public class OperacaoMatematica {
    public void calcular(double a, double b){
        System.out.println("A operação não foi definida");
    }
}
